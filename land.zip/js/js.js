// JavaScript Document
jQuery.noConflict();
jQuery(document).ready(function () {
jQuery(window).resize(function() {
	var width_content = jQuery(window).width();
	if(width_content<=752){
		jQuery('#nav_new_home #site-navigation').addClass('plus_adapt');
	}
	else{
		jQuery('#nav_new_home #site-navigation').removeClass('plus_adapt');
		}
});

		jQuery(".fancybox").fancybox();

jQuery("#owl-example").owlCarousel({
 
      autoPlay: 3000, //Set AutoPlay to 3 seconds
 
      items : 4,
      itemsDesktop : [1199,3],
      itemsDesktopSmall : [979,3],
	  navigation : true
 
  });
  	jQuery(".fancybox").fancybox();

jQuery("#owl-example2").owlCarousel({ 
 
      autoPlay: 3000, //Set AutoPlay to 3 seconds
 
      items : 1,
      itemsDesktop : [1199,1],
      itemsDesktopSmall : [979,1], 
	  navigation : true
 
  });



	
		
  jQuery('a[href*=#]').bind("click", function(e){
var anchor = jQuery(this);
jQuery('html, body').stop().animate({
scrollTop: jQuery(anchor.attr('href')).offset().top
}, 1000);
e.preventDefault();
return false;
});


 jQuery('#form1').validate({
         rules: {
                      name: {
						  required:true
						},
                      tel: {
                          required: true
                      }
                  },
                  messages: {
                      name: {
					     required: "Введите Ваше имя"
					  },
                      tel: {
					     required: "Введите Ваш номер телефона"
					 }
                  },
         submitHandler: function(form){			
  
  var name = jQuery('#form1').find('input[name="name"]').val();
  var tel = jQuery('#form1').find('input[name="tel"]').val();
  var email = jQuery('#form1').find('input[name="email"]').val();
  var textarea = jQuery('#form1').find('input[name="textarea"').val();
  
  jQuery.post(
  "/contact.php",
  {
  name: name,
  tel: tel,
  email: email,
  textarea: textarea
  }),
        jQuery('#modal_window').animate({opacity: 'show'}, 400);
		setTimeout(function(){
  			jQuery('#modal_window').animate({opacity: 'hide'}, 400);
		},3000);
	jQuery('#form1 input[type="text"]').val('');
	jQuery('#form1 input[type="tel"]').val('');
	jQuery('#form1 input[type="email"]').val('');
	jQuery('#form1 input[type="textarea"]').val('');
         } 
      });
	  
	  
	  
	  
	  
	  
	   jQuery('#call_back').validate({
         rules: {
                      name2: {
						  required:true
						},
                      tel2: {
                          required: true
                      }
                  },
                  messages: {
                      name2: {
					     required: "Введите Ваше имя"
					  },
                      tel2: {
					     required: "Введите Ваш номер телефона"
					 }
                  },
         submitHandler: function(form){			
  
  var name2 = jQuery('#call_back').find('input[name="name2"]').val();
  var tel2 = jQuery('#call_back').find('input[name="tel2"]').val();
  
  jQuery.post(
  "/contact2.php",
  {
  name2: name2,
  tel2: tel2,
  }),

        jQuery('#modal_window2').animate({opacity: 'show'}, 400);
		setTimeout(function(){
  			jQuery('#modal_window2').animate({opacity: 'hide'}, 400);
		},3000);
	jQuery('#call_back input[type="text"]').val('');
	jQuery('#call_back input[type="tel"]').val('');
	 jQuery(".close").trigger('click');
         } 
      });
});	



